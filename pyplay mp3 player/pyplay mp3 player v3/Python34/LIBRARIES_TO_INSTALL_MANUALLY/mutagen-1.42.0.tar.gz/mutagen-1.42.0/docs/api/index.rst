API Reference
=============

.. toctree::

    base
    aac
    aiff
    ape
    asf
    dsf
    flac
    id3
    monkeysaudio
    mp3
    mp4
    musepack
    ogg
    oggflac
    oggopus
    oggspeex
    oggtheora
    oggvorbis
    optimfrog
    smf
    trueaudio
    vcomment
    wavpack
