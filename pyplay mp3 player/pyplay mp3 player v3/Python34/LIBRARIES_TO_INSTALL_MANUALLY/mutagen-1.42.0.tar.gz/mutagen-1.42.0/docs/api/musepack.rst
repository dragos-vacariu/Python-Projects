Musepack
========

.. automodule:: mutagen.musepack

.. autoclass:: mutagen.musepack.Musepack
    :show-inheritance:
    :members:

.. autoclass:: mutagen.musepack.MusepackInfo
    :show-inheritance:
    :members:
