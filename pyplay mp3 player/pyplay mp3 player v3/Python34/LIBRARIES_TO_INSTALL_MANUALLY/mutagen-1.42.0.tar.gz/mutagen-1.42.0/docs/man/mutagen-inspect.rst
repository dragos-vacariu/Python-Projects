=================
 mutagen-inspect
=================

---------------------------------
view Mutagen-supported audio tags
---------------------------------

:Manual section: 1


SYNOPSIS
========

**mutagen-inspect** *filename* ...


DESCRIPTION
===========

**mutagen-inspect** loads and prints information about an audio file and
its tags.

It is primarily intended as a debugging tool for Mutagen, but can be useful
for extracting tags from the command line.


AUTHOR
======

Joe Wreschnig
