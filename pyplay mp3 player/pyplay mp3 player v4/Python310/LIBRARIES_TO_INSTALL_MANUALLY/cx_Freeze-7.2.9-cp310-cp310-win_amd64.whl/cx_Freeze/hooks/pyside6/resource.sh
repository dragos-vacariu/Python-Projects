#!/bin/bash

pyside6-rcc -o resource.py resource.qrc
