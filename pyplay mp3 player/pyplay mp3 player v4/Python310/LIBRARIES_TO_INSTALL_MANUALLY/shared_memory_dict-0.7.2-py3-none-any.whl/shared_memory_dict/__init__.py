from .dict import SharedMemoryDict  # noqa
