MEMORY_NAME = 'sm_{name}'
